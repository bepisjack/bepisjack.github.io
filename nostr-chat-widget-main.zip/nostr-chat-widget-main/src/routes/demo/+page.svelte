<!DOCTYPE html>
<html lang="en">
<meta charset="UTF-8">
<title>Demo page</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="stylesheet" href="public/bundle.css">
<body>

  <h1>Svelte embedding demo</h1>

  <p>Below,we have inserted a <code>script</code> tag that should
  renter a Svelte component upon loading this page.</p>

  <script
    src="/public/bundle.js"
    data-website-owner-pubkey="fa984bd7dbb282f07e16e7ae87b26a2a7b9b90b7246a44771f0cf5ae58018f52"
    data-chat-type="GROUP"
    data-chat-id="a6f436a59fdb5e23c757b1e30478742996c54413df777843e0a731af56a96eea"
    data-relays="wss://relay.f7z.io,wss://nos.lol,wss://relay.nostr.info,wss://nostr-pub.wellorder.net,wss://relay.current.fyi,wss://relay.nostr.band"
  ></script>

  <p>This text will come after the embedded content.</p>
</body>
</html>
